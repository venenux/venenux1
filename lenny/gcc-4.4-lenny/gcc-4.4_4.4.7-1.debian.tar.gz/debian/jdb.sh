#!/bin/sh

# Placeholder script to fake a
# JDK compatible JAVA_HOME directory.

echo >&2 "This script is only a placeholder."
echo >&2 "Some programs need a JDK rather than only a JRE to work."
echo >&2 "They test for this tool to detect a JDK installation, but"
echo >&2 "don't really need its functionality to work correctly."
