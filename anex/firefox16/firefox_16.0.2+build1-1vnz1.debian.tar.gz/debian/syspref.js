// This file can be used to configure global preferences for Firefox
// Example: Homepage
pref("browser.startup.homepage", "http://vegnuli.blogspot.com/");

pref("startup.homepage_override_url","http://vegnuli.blogspot.com/");
pref("startup.homepage_welcome_url","http://vegnuli.blogspot.com/");
pref("app.releaseNotesURL", "http://mozilla.debian.net/%LOCALE%/%APP%/%VERSION%/releasenotes/");
