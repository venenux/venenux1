// Enable extensions in the application directory
pref("extensions.enabledScopes", 5);
