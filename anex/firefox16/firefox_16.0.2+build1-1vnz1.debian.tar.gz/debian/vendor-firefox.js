// Disable default browser checking.
pref("browser.shell.checkDefaultBrowser", false);

// Don't disable extensions dropped in to a system
// location, or those owned by the application
pref("extensions.autoDisableScopes", 3);

// Don't display the one-off addon selection dialog when
// upgrading from a version of Firefox older than 8.0
pref("extensions.shownSelectionUI", true);
// Forbid application updates
lockPref("app.update.enabled", false);

// Pointing the "Help -> What's new" menu entry to mozilla.debian.net
pref("mailnews.start_page.override_url", "http://vegnuli.blogspot.com");

