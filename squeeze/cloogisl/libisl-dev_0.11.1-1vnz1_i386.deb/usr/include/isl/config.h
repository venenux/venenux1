/* include/isl/config.h.  Generated from config.h.in by configure.  */
#define GCC_WARN_UNUSED_RESULT __attribute__((__warn_unused_result__))

/* #undef ISL_PIPLIB */
