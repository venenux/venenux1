char **parse_conf (unsigned int argc, char **argv);
void filterout_libdir_path (void);
